

Die modifizierte natdin.bst basiert auf Vers. [3.1] 2006-01-02.

Zun�chst ist das din1505-Paket zu installieren.
Die originale natdin.bst, �blicherweise in .../MiKTeX/bibtex/bst/din1505/ zu finden, ist anschlie�end zu �berschreiben.




Es wurden �nderungen zum Gestaltung des Literaturverzeichnisses vorgenommen.
Diese sind in natdin.bst allesamt dokumentiert/kommentiert und zu finden, indem nach "UniHH-ITG" gesucht wird.



Wichtigste �nderungen:
###############################
- Zeilenumbruch nach Nennung eines Autors im Literaturverzeichnis
- Autorennamen in Kapit�lchen ---> [M�LLER 2010] statt [M�ller 2010]
- Verwendung von "et al." statt "u.a." --> [M�LLER et al. 2010]
- Verwendung von "und" statt "u." --> [M�LLER und SCHULZE 2010]
- Anpassung an die standardm��ig von Citavi exportierten Felder bei Internetquellen, so dass ein "Abruf am tt.mm.jjjj" im Literaturverzeichnis erscheint.
- Einbau eines \noparagraphbreak f�r Literatureintr�ge, so dass diese nicht �ber zwei Seiten umgebrochen werden (vgl. Latex-Konfiguration)